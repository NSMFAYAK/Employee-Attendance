let records = [
  {id:'E001', name:'Asha Kumar', date:'2025-11-01', in:'09:05', out:'17:15', status:'present', notes:''},
  {id:'E002', name:'Rohit Singh', date:'2025-11-01', in:'09:35', out:'17:10', status:'late', notes:'Traffic'},
  {id:'E003', name:'Priya Sharma', date:'2025-11-01', in:'', out:'', status:'absent', notes:'Sick leave'}
];

// DOM elements
const tbody = document.querySelector("#attendanceTable tbody");
const search = document.getElementById("search");
const fromDate = document.getElementById("fromDate");
const toDate = document.getElementById("toDate");
const statusFilter = document.getElementById("statusFilter");
const summary = document.getElementById("summary");

// Render table
function renderTable() {
  const q = search.value.toLowerCase();
  const from = fromDate.value;
  const to = toDate.value;
  const st = statusFilter.value;

  let filtered = records.filter(r => {
    if (q && !(`${r.name} ${r.id}`.toLowerCase().includes(q))) return false;
    if (st !== "all" && r.status !== st) return false;
    if (from && r.date < from) return false;
    if (to && r.date > to) return false;
    return true;
  });

  tbody.innerHTML = "";
  filtered.forEach(r => {
    let row = `
      <tr>
        <td>${r.id}</td>
        <td>${r.name}</td>
        <td>${r.date}</td>
        <td>${r.in || "-"}</td>
        <td>${r.out || "-"}</td>
        <td><span class="status ${r.status}">${r.status}</span></td>
        <td>${r.notes || "-"}</td>
        <td>
          <button onclick="editRecord('${r.id}','${r.date}')">Edit</button>
          <button onclick="deleteRecord('${r.id}','${r.date}')" style="background:#ef4444">Delete</button>
        </td>
      </tr>`;
    tbody.innerHTML += row;
  });

  renderSummary(filtered);
}

// Summary
function renderSummary(filtered) {
  const total = filtered.length;
  const present = filtered.filter(r=>r.status==='present').length;
  const absent = filtered.filter(r=>r.status==='absent').length;
  const late = filtered.filter(r=>r.status==='late').length;

  summary.innerHTML = `
    <div class="stat"><div class="small">Records</div><strong>${total}</strong></div>
    <div class="stat"><div class="small">Present</div><strong>${present}</strong></div>
    <div class="stat"><div class="small">Absent</div><strong>${absent}</strong></div>
    <div class="stat"><div class="small">Late</div><strong>${late}</strong></div>
  `;
}

// Modal logic
const modal = document.getElementById("modal");
const modalTitle = document.getElementById("modalTitle");
const mId = document.getElementById("mId");
const mName = document.getElementById("mName");
const mDate = document.getElementById("mDate");
const mIn = document.getElementById("mIn");
const mOut = document.getElementById("mOut");
const mStatus = document.getElementById("mStatus");
const mNotes = document.getElementById("mNotes");
let editingKey = null;

document.getElementById("addBtn").onclick = () => openModal();
document.getElementById("cancelModal").onclick = closeModal;
document.getElementById("saveModal").onclick = saveModal;

function openModal(record) {
  modal.style.display = "flex";

  if (record) {
    modalTitle.textContent = "Edit Record";
    mId.value = record.id; mId.disabled = true;
    mName.value = record.name;
    mDate.value = record.date;
    mIn.value = record.in;
    mOut.value = record.out;
    mStatus.value = record.status;
    mNotes.value = record.notes;
    editingKey = record.id + "|" + record.date;
  } else {
    modalTitle.textContent = "Add Record";
    mId.disabled = false;
    mId.value = mName.value = mDate.value = mIn.value = mOut.value = mNotes.value = "";
    mStatus.value = "present";
    editingKey = null;
  }
}

function closeModal() { modal.style.display = "none"; }

function saveModal() {
  const rec = {
    id: mId.value.trim(),
    name: mName.value.trim(),
    date: mDate.value,
    in: mIn.value,
    out: mOut.value,
    status: mStatus.value,
    notes: mNotes.value.trim()
  };

  if (!rec.id || !rec.name || !rec.date) return alert("ID, Name, Date required!");

  if (editingKey) {
    const idx = records.findIndex(r => r.id+"|"+r.date === editingKey);
    records[idx] = rec;
  } else {
    records.push(rec);
  }

  closeModal();
  renderTable();
}

// Edit/Delete
window.editRecord = (id, date) => {
  const r = records.find(x => x.id===id && x.date===date);
  openModal(r);
}

window.deleteRecord = (id, date) => {
  if (confirm("Delete this record?")) {
    records = records.filter(r => !(r.id===id && r.date===date));
    renderTable();
  }
};

// Export CSV
document.getElementById("exportBtn").onclick = () => {
  let rows = ["ID,Name,Date,Check-in,Check-out,Status,Notes"];

  records.forEach(r => {
    rows.push(`"${r.id}","${r.name}","${r.date}","${r.in}","${r.out}","${r.status}","${r.notes}"`);
  });

  const blob = new Blob([rows.join("\n")], {type:"text/csv"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "attendance.csv";
  a.click();
};

// Filters update table
[search, fromDate, toDate, statusFilter].forEach(el => 
  el.addEventListener("input", renderTable)
);

// Initial render
renderTable();
